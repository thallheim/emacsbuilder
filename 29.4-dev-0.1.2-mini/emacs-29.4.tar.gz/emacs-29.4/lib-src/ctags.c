#define CTAGS 1
#include "etags.c"
